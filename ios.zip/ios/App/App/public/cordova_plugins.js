
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-inappbrowser.inappbrowser",
          "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
          "pluginId": "cordova-plugin-inappbrowser",
        "clobbers": [
          "cordova.InAppBrowser.open"
        ]
        },
      {
          "id": "com.omarben.inappreview.inappreview",
          "file": "plugins/com.omarben.inappreview/www/inappreview.js",
          "pluginId": "com.omarben.inappreview",
        "clobbers": [
          "inappreview"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "com.omarben.inappreview": "0.0.5",
      "cordova-plugin-inappbrowser": "5.0.0"
    };
    // BOTTOM OF METADATA
    });
    