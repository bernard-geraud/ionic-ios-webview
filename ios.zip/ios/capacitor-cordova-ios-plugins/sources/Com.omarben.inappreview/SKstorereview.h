#import <Cordova/CDV.h>

@interface SKstorereview : CDVPlugin

- (void) requestReview:(CDVInvokedUrlCommand*)command;

@end